﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Ekz.Program;

namespace Ekz
{
    public partial class MainForm : Form
    {
        private MusicStoreService _service;

        public MainForm()
        {
            InitializeComponent();
            var database = new Database("your_connection_string_here");
            _service = new MusicStoreService(database);
            LoadVinylRecords();
        }

        private void LoadVinylRecords()
        {
            var records = _service.GetAllVinylRecords();
            dataGridViewRecords.DataSource = records;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var record = new VinylRecord
            {
                Title = txtTitle.Text,
                Artist = txtArtist.Text,
                Publisher = txtPublisher.Text,
                TracksCount = int.Parse(txtTracksCount.Text),
                Genre = txtGenre.Text,
                ReleaseYear = int.Parse(txtReleaseYear.Text),
                CostPrice = decimal.Parse(txtCostPrice.Text),
                SalePrice = decimal.Parse(txtSalePrice.Text)
            };

            _service.AddVinylRecord(record);
            LoadVinylRecords();
            MessageBox.Show("Пластинка добавлена!");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewRecords.SelectedRows.Count > 0)
            {
                int id = (int)dataGridViewRecords.SelectedRows[0].Cells["Id"].Value;
                _service.DeleteVinylRecord(id);
                LoadVinylRecords();
                MessageBox.Show("Пластинка удалена!");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridViewRecords.SelectedRows.Count > 0)
            {
                var record = new VinylRecord
                {
                    Id = (int)dataGridViewRecords.SelectedRows[0].Cells["Id"].Value,
                    Title = txtTitle.Text,
                    Artist = txtArtist.Text,
                    Publisher = txtPublisher.Text,
                    TracksCount = int.Parse(txtTracksCount.Text),
                    Genre = txtGenre.Text,
                    ReleaseYear = int.Parse(txtReleaseYear.Text),
                    CostPrice = decimal.Parse(txtCostPrice.Text),
                    SalePrice = decimal.Parse(txtSalePrice.Text)
                };

                _service.UpdateVinylRecord(record);
                LoadVinylRecords();
                MessageBox.Show("Пластинка обновлена!");
            }
        }
    }
}
