﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Configuration.Provider;
using System.Data.SqlClient;
using System.Text;

namespace Ekz
{
    internal class Program
    {
        public class VinylRecord
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string Artist { get; set; }
            public string Publisher { get; set; }
            public int TracksCount { get; set; }
            public string Genre { get; set; }
            public int ReleaseYear { get; set; }
            public decimal CostPrice { get; set; }
            public decimal SalePrice { get; set; }
        }

        public class Database
        {
            private readonly string connectionString = ConfigurationManager.ConnectionStrings["MusicStoreDB"]?.ConnectionString;

            public Database(string connectionString)
            {
                this.connectionString = connectionString;
            }

            public SqlConnection GetConnection()
            {
                var connection = new SqlConnection(connectionString);
                connection.Open();
                return connection;
            }
        }

        public class MusicStoreService
        {
            private readonly Database _database;

            public MusicStoreService(Database database)
            {
                _database = database;
            }

            public void AddVinylRecord(VinylRecord record)
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand(
                        "INSERT INTO VinylRecords (Title, Artist, Publisher, TracksCount, Genre, ReleaseYear, CostPrice, SalePrice) VALUES (@Title, @Artist, @Publisher, @TracksCount, @Genre, @ReleaseYear, @CostPrice, @SalePrice)",
                        connection);

                    command.Parameters.AddWithValue("@Title", record.Title);
                    command.Parameters.AddWithValue("@Artist", record.Artist);
                    command.Parameters.AddWithValue("@Publisher", record.Publisher);
                    command.Parameters.AddWithValue("@TracksCount", record.TracksCount);
                    command.Parameters.AddWithValue("@Genre", record.Genre);
                    command.Parameters.AddWithValue("@ReleaseYear", record.ReleaseYear);
                    command.Parameters.AddWithValue("@CostPrice", record.CostPrice);
                    command.Parameters.AddWithValue("@SalePrice", record.SalePrice);

                    command.ExecuteNonQuery();
                }
            }

            public void DeleteVinylRecord(int id)
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand("DELETE FROM VinylRecords WHERE Id = @Id", connection);
                    command.Parameters.AddWithValue("@Id", id);
                    command.ExecuteNonQuery();
                }
            }

            public void SellVinylRecord(int id, int quantity)
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand(
                        "INSERT INTO Sales (VinylRecordId, Date, Quantity) VALUES (@VinylRecordId, @Date, @Quantity)",
                        connection);

                    command.Parameters.AddWithValue("@VinylRecordId", id);
                    command.Parameters.AddWithValue("@Date", DateTime.Now);
                    command.Parameters.AddWithValue("@Quantity", quantity);

                    command.ExecuteNonQuery();
                }
            }

            public void ApplyDiscountToGenre(string genre, double discountPercentage)
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand(
                        "UPDATE VinylRecords SET SalePrice = SalePrice * (1 - @DiscountPercentage) WHERE Genre = @Genre",
                        connection);

                    command.Parameters.AddWithValue("@DiscountPercentage", discountPercentage / 100);
                    command.Parameters.AddWithValue("@Genre", genre);

                    command.ExecuteNonQuery();
                }
            }

            public void ReserveVinylRecord(int id, string customerName)
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand(
                        "INSERT INTO Reservations (VinylRecordId, CustomerName, ReservationDate) VALUES (@VinylRecordId, @CustomerName, @ReservationDate)",
                        connection);

                    command.Parameters.AddWithValue("@VinylRecordId", id);
                    command.Parameters.AddWithValue("@CustomerName", customerName);
                    command.Parameters.AddWithValue("@ReservationDate", DateTime.Now);

                    command.ExecuteNonQuery();
                }
            }

            public List<VinylRecord> GetNewArrivals()
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand("SELECT * FROM VinylRecords WHERE ReleaseYear = YEAR(GETDATE())", connection);
                    var reader = command.ExecuteReader();

                    var records = new List<VinylRecord>();
                    while (reader.Read())
                    {
                        records.Add(new VinylRecord
                        {
                            Id = (int)reader["Id"],
                            Title = (string)reader["Title"],
                            Artist = (string)reader["Artist"],
                            Publisher = (string)reader["Publisher"],
                            TracksCount = (int)reader["TracksCount"],
                            Genre = (string)reader["Genre"],
                            ReleaseYear = (int)reader["ReleaseYear"],
                            CostPrice = (decimal)reader["CostPrice"],
                            SalePrice = (decimal)reader["SalePrice"],
                        });
                    }

                    return records;
                }
            }

            public List<int> GetBestSellingVinylRecords()
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand(@"SELECT TOP 5 VinylRecordId FROM Sales
                                           GROUP BY VinylRecordId
                                           ORDER BY SUM(Quantity) DESC", connection);
                    var reader = command.ExecuteReader();

                    var topSellingIds = new List<int>();
                    while (reader.Read())
                    {
                        topSellingIds.Add((int)reader["VinylRecordId"]);
                    }

                    return topSellingIds;
                }
            }

            public void UpdateVinylRecord(VinylRecord record)
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand(
                        "UPDATE VinylRecords SET Title = @Title, Artist = @Artist, Publisher = @Publisher, TracksCount = @TracksCount, Genre = @Genre, ReleaseYear = @ReleaseYear, CostPrice = @CostPrice, SalePrice = @SalePrice WHERE Id = @Id",
                        connection);

                    command.Parameters.AddWithValue("@Id", record.Id);
                    command.Parameters.AddWithValue("@Title", record.Title);
                    command.Parameters.AddWithValue("@Artist", record.Artist);
                    command.Parameters.AddWithValue("@Publisher", record.Publisher);
                    command.Parameters.AddWithValue("@TracksCount", record.TracksCount);
                    command.Parameters.AddWithValue("@Genre", record.Genre);
                    command.Parameters.AddWithValue("@ReleaseYear", record.ReleaseYear);
                    command.Parameters.AddWithValue("@CostPrice", record.CostPrice);
                    command.Parameters.AddWithValue("@SalePrice", record.SalePrice);

                    command.ExecuteNonQuery();
                }
            }

            // Метод для поиска пластинок по различным параметрам
            public List<VinylRecord> SearchVinylRecords(string title = null, string artist = null, string genre = null)
            {
                using (var connection = _database.GetConnection())
                {
                    var query = new StringBuilder("SELECT * FROM VinylRecords WHERE 1=1");
                    if (!string.IsNullOrEmpty(title))
                    {
                        query.Append(" AND Title LIKE @Title");
                    }
                    if (!string.IsNullOrEmpty(artist))
                    {
                        query.Append(" AND Artist LIKE @Artist");
                    }
                    if (!string.IsNullOrEmpty(genre))
                    {
                        query.Append(" AND Genre LIKE @Genre");
                    }

                    var command = new SqlCommand(query.ToString(), connection);
                    if (!string.IsNullOrEmpty(title))
                    {
                        command.Parameters.AddWithValue("@Title", "%" + title + "%");
                    }
                    if (!string.IsNullOrEmpty(artist))
                    {
                        command.Parameters.AddWithValue("@Artist", "%" + artist + "%");
                    }
                    if (!string.IsNullOrEmpty(genre))
                    {
                        command.Parameters.AddWithValue("@Genre", "%" + genre + "%");
                    }

                    var reader = command.ExecuteReader();
                    var records = new List<VinylRecord>();
                    while (reader.Read())
                    {
                        records.Add(new VinylRecord
                        {
                            Id = (int)reader["Id"],
                            Title = (string)reader["Title"],
                            Artist = (string)reader["Artist"],
                            Publisher = (string)reader["Publisher"],
                            TracksCount = (int)reader["TracksCount"],
                            Genre = (string)reader["Genre"],
                            ReleaseYear = (int)reader["ReleaseYear"],
                            CostPrice = (decimal)reader["CostPrice"],
                            SalePrice = (decimal)reader["SalePrice"],
                        });
                    }
                    return records;
                }
            }

            public List<VinylRecord> GetAllVinylRecords()
            {
                using (var connection = _database.GetConnection())
                {
                    var command = new SqlCommand("SELECT * FROM VinylRecords", connection);
                    var reader = command.ExecuteReader();

                    var records = new List<VinylRecord>();
                    while (reader.Read())
                    {
                        records.Add(new VinylRecord
                        {
                            Id = (int)reader["Id"],
                            Title = (string)reader["Title"],
                            Artist = (string)reader["Artist"],
                            Publisher = (string)reader["Publisher"],
                            TracksCount = (int)reader["TracksCount"],
                            Genre = (string)reader["Genre"],
                            ReleaseYear = (int)reader["ReleaseYear"],
                            CostPrice = (decimal)reader["CostPrice"],
                            SalePrice = (decimal)reader["SalePrice"],
                        });
                    }

                    return records;
                }
            }

            static void Main(string[] args)
            {
                // Пример строки подключения. Не забудьте заменить ее на вашу.
                string connectionString = ConfigurationManager.ConnectionStrings["MusicStore"]?.ConnectionString;

                // Создание экземпляра класса базы данных и сервиса магазина
                Database database = new Database(connectionString);
                MusicStoreService storeService = new MusicStoreService(database);

                // Добавление новой пластинки
                VinylRecord newRecord = new VinylRecord
                {
                    Title = "New Album",
                    Artist = "New Artist",
                    Publisher = "New Publisher",
                    TracksCount = 10,
                    Genre = "Rock",
                    ReleaseYear = 2025,
                    CostPrice = 50.00m,
                    SalePrice = 70.00m
                };

                storeService.AddVinylRecord(newRecord);
                Console.WriteLine("Новая пластинка добавлена.");

                // Получение и отображение всех пластинок
                Console.WriteLine("\nСписок всех пластинок:");
                List<VinylRecord> records = storeService.GetAllVinylRecords();
                foreach (var record in records)
                {
                    Console.WriteLine($"Id: {record.Id}, Title: {record.Title}, Artist: {record.Artist}, Genre: {record.Genre}");
                }

                // Обновление информации о пластинке
                if (records.Count > 0)
                {
                    VinylRecord recordToUpdate = records[0];
                    recordToUpdate.Title = "Updated Album";
                    storeService.UpdateVinylRecord(recordToUpdate);
                    Console.WriteLine("\nПервая пластинка обновлена.");
                }

                // Получение и отображение обновленного списка пластинок
                Console.WriteLine("\nОбновленный список всех пластинок:");
                records = storeService.GetAllVinylRecords();
                foreach (var record in records)
                {
                    Console.WriteLine($"Id: {record.Id}, Title: {record.Title}, Artist: {record.Artist}, Genre: {record.Genre}");
                }
            }
        }
    }
}
